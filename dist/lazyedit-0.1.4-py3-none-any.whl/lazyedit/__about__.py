# SPDX-FileCopyrightText: 2025-present Robbe <robbe.van.herpe@outlook.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.4"
