# lazyEdit

[![PyPI - Version](https://img.shields.io/pypi/v/lazyedit.svg)](https://pypi.org/project/lazyedit)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/lazyedit.svg)](https://pypi.org/project/lazyedit)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install lazyedit
```

## Run Localy Test

```console
hatch env create
hatch shell 
pip instal
lazyedit 
```

## License

`lazyedit` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
