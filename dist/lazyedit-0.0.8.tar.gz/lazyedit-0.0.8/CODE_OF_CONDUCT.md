# Code of Conduct: The “Just Be Cool” Edition

1. Be kind (high-fives > insults).
2. Keep it fun, not sketchy.
3. If you slip up, I will find u, apologize, and bring snacks.

Have fun!